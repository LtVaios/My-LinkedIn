package uoa.di.tedbackend.friends_impl;

import org.springframework.data.jpa.repository.JpaRepository;

interface FriendsRepository extends JpaRepository<Friends, Integer>{
}

