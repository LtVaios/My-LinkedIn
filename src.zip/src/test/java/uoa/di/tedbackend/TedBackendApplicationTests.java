package uoa.di.tedbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TedBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
